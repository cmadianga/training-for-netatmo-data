#!/bin/sh
set -eu

BINARIES_DIR="$1"
ROOTFS_TAR="${BINARIES_DIR}/rootfs.tar"

WANTS_DIR="etc/systemd/system/multi-user.target.wants"
OLD_LINK="${WANTS_DIR}/wpa_supplicant.service"
NEW_LINK="${WANTS_DIR}/wpa_supplicant@wlan0.service"
UNIT_TARGET="/usr/lib/systemd/system/wpa_supplicant@.service"

if [ ! -f "${ROOTFS_TAR}" ]; then
    echo "Error: ${ROOTFS_TAR} not found"
    exit 1
fi

WORKDIR="$(mktemp -d)"
trap 'rm -rf "${WORKDIR}"' EXIT

echo "Extracting ${ROOTFS_TAR}..."
tar -xf "${ROOTFS_TAR}" -C "${WORKDIR}"

mkdir -p "${WORKDIR}/${WANTS_DIR}"
rm -f "${WORKDIR}/${OLD_LINK}" "${WORKDIR}/${NEW_LINK}"

ln -snf "${UNIT_TARGET}" "${WORKDIR}/${NEW_LINK}"

echo "Repacking ${ROOTFS_TAR}..."
tar -cf "${ROOTFS_TAR}.new" -C "${WORKDIR}" .
mv "${ROOTFS_TAR}.new" "${ROOTFS_TAR}"

echo "Updated ${ROOTFS_TAR}:"
echo "  removed ${OLD_LINK}"
echo "  created ${NEW_LINK} -> ${UNIT_TARGET}"
