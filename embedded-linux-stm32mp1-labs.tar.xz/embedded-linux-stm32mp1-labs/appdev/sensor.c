/* name=sensor.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <limits.h>

static int read_long_from_file(const char *path, long *out)
{
    FILE *f = fopen(path, "r");
    if (!f) return -1;

    long v;
    int rc = fscanf(f, "%ld", &v);
    fclose(f);

    if (rc != 1) return -1;
    *out = v;
    return 0;
}

static int find_hwmon_path(char *temp_path, size_t temp_sz,
                           char *hum_path, size_t hum_sz)
{
    DIR *d = opendir("/sys/class/hwmon");
    if (!d) return -1;

    struct dirent *de;
    while ((de = readdir(d)) != NULL) {
        if (strncmp(de->d_name, "hwmon", 5) != 0)
            continue;

        char name_path[PATH_MAX];
        char name[128] = {0};

        snprintf(name_path, sizeof(name_path),
                 "/sys/class/hwmon/%s/name", de->d_name);

        FILE *f = fopen(name_path, "r");
        if (!f) continue;

        if (!fgets(name, sizeof(name), f)) {
            fclose(f);
            continue;
        }
        fclose(f);

        name[strcspn(name, "\r\n")] = 0;

        /* Adjust this match if your driver uses a different name */
        if (strstr(name, "sht31") || strstr(name, "sht3") || strstr(name, "sht")) {
            snprintf(temp_path, temp_sz,
                     "/sys/class/hwmon/%s/temp1_input", de->d_name);
            snprintf(hum_path, hum_sz,
                     "/sys/class/hwmon/%s/humidity1_input", de->d_name);
            closedir(d);
            return 0;
        }
    }

    closedir(d);
    return -1;
}

int main(void)
{
    char temp_path[PATH_MAX] = {0};
    char hum_path[PATH_MAX] = {0};
    long temp_raw = 0;
    long hum_raw = 0;

    printf("Content-Type: text/html\r\n\r\n");
    printf("<!doctype html><html><head>");
    printf("<meta charset=\"utf-8\">");
    printf("<meta http-equiv=\"refresh\" content=\"5\">");
    printf("<title>Sensor Status</title>");
    printf("<style>body{font-family:sans-serif;margin:2em;} .v{font-size:2em;}</style>");
    printf("</head><body>");
    printf("<h1>SHT31-D Sensor</h1>");

    if (find_hwmon_path(temp_path, sizeof(temp_path), hum_path, sizeof(hum_path)) != 0) {
        printf("<p><b>Error:</b> could not find SHT31 hwmon device.</p>");
        printf("</body></html>");
        return 0;
    }

    if (read_long_from_file(temp_path, &temp_raw) != 0) {
        printf("<p><b>Error:</b> could not read %s</p>", temp_path);
        printf("</body></html>");
        return 0;
    }

    if (read_long_from_file(hum_path, &hum_raw) != 0) {
        printf("<p><b>Error:</b> could not read %s</p>", hum_path);
        printf("</body></html>");
        return 0;
    }

    /* temp_input is usually millidegrees C */
    printf("<p>Temperature: <span class=\"v\">%.1f &deg;C</span></p>",
           temp_raw / 1000.0);

    /*
     * humidity_input is often milli-%RH on hwmon drivers.
     * If yours is already in %RH, remove the / 1000.0.
     */
    printf("<p>Humidity: <span class=\"v\">%.1f %%RH</span></p>",
           hum_raw / 1000.0);

    printf("</body></html>");
    return 0;
}
