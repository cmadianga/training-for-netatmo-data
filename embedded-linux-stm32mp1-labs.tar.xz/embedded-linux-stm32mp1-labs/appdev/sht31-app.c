#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <limits.h>
#include <unistd.h>
#include <sys/select.h>

static int read_long_from_file(const char *path, long *out)
{
    FILE *f = fopen(path, "r");
    if (!f) return -1;

    long v;
    int rc = fscanf(f, "%ld", &v);
    fclose(f);

    if (rc != 1) return -1;
    *out = v;
    return 0;
}

static int find_hwmon_path(char *temp_path, size_t temp_sz,
                           char *hum_path, size_t hum_sz)
{
    DIR *d = opendir("/sys/class/hwmon");
    if (!d) return -1;

    struct dirent *de;
    while ((de = readdir(d)) != NULL) {
        if (strncmp(de->d_name, "hwmon", 5) != 0)
            continue;

        char name_path[PATH_MAX];
        char name[128] = {0};

        snprintf(name_path, sizeof(name_path),
                 "/sys/class/%s/name", de->d_name);

        FILE *f = fopen(name_path, "r");
        if (!f) continue;

        if (!fgets(name, sizeof(name), f)) {
            fclose(f);
            continue;
        }
        fclose(f);

        name[strcspn(name, "\r\n")] = 0;

        if (strstr(name, "sensirion")) {
            snprintf(temp_path, temp_sz,
                     "/sys/class/hwmon/%s/temp1_input", de->d_name);
            snprintf(hum_path, hum_sz,
                     "/sys/class/hwmon/%s/humidity1_input", de->d_name);
            closedir(d);
            return 0;
        }
    }

    closedir(d);
    return -1;
}

static int q_pressed(void)
{
    fd_set fds;
    struct timeval tv;
    char buf[32];

    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    tv.tv_sec = 0;
    tv.tv_usec = 0;

    if (select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv) > 0) {
        if (fgets(buf, sizeof(buf), stdin)) {
            if (buf[0] == 'q' || buf[0] == 'Q')
                return 1;
        }
    }
    return 0;
}

int main(void)
{
    char *temp_path;
    char *hum_path;
    
    temp_path = calloc(PATH_MAX, sizeof(char));
    if (!temp_path)
	    return EXIT_FAILURE;
    
    hum_path = calloc(PATH_MAX, sizeof(char));
    if (!hum_path)
	    return EXIT_FAILURE;

    if (find_hwmon_path(temp_path, PATH_MAX, hum_path, PATH_MAX) != 0) {
        fprintf(stderr, "Error: SHT31 sensor not found in /sys/class/hwmon\n");
        return 1;
    }

    printf("Sensor found:\n");
    printf("  Temperature: %s\n", temp_path);
    printf("  Humidity : %s\n", hum_path);
    printf("\nPress Q then Enter to exit.\n\n");

    while (1) {
        long temp_raw = 0;
        long hum_raw = 0;

        if (read_long_from_file(temp_path, &temp_raw) != 0) {
            fprintf(stderr, "Error during temperature reading\n");
            break;
        }

        if (read_long_from_file(hum_path, &hum_raw) != 0) {
            fprintf(stderr, "Erreur during humidity reading\n");
            break;
        }

        printf("Temperature : %.1f °C | Humidity : %.1f %%RH\n",
               temp_raw / 1000.0, hum_raw / 1000.0);
        fflush(stdout);

        for (int i = 0; i < 1; i++) {
            sleep(1);
            if (q_pressed()) {
                free(temp_path);
		free(hum_path);
		break;
	    }
        }
    }

    free(temp_path);
    free(hum_path);
    
    return 0;
}
